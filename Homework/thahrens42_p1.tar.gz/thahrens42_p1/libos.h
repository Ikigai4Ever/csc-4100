int term_txtheight();
int term_txtwidth();
void print_to(unsigned int row, unsigned int col, const char *str);
void putc_to(unsigned int row, unsigned int col, const char c);
